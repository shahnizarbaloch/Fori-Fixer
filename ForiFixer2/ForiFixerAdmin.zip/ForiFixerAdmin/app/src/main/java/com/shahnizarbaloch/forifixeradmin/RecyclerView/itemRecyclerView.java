package com.shahnizarbaloch.forifixeradmin.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.shahnizarbaloch.forifixeradmin.R;
import com.shahnizarbaloch.forifixeradmin.model.itemDetail;

import java.util.ArrayList;

public class itemRecyclerView extends android.support.v7.widget.RecyclerView.Adapter<itemRecyclerView.MyViewHolder>{

    private ArrayList<itemDetail> arrayList;
    private Context context;


    public itemRecyclerView(ArrayList<itemDetail> arrayList, Context context) {
        this.arrayList=arrayList;
        this.context=context;
    }

    @NonNull
    @Override
    public itemRecyclerView.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflater = LayoutInflater.from(context);
        @SuppressLint("InflateParams") final View view = inflater.inflate(R.layout.rv_order_item, null, false);

        final itemRecyclerView.MyViewHolder myViewHolder = new itemRecyclerView.MyViewHolder(view);


        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull itemRecyclerView.MyViewHolder myViewHolder, int i) {

        itemDetail obj= arrayList.get(i);
        myViewHolder.itemName.setText(obj.getItemName());
        myViewHolder.itemPrice.setText(obj.getItemPrice());

    }


    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    class MyViewHolder extends android.support.v7.widget.RecyclerView.ViewHolder{
        RelativeLayout itemDetail;
        TextView itemName,itemPrice;
        android.support.v7.widget.RecyclerView rv;
        MyViewHolder(@NonNull View itemView) {
            super(itemView);
            itemDetail = itemView.findViewById(R.id.item_rv);
            itemName=itemView.findViewById(R.id.tv_item_name);
            itemPrice=itemView.findViewById(R.id.tv_item_price);
            rv = itemView.findViewById(R.id.item_recycler_view);
        }
    }
}
