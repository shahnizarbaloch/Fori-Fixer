package com.shahnizarbaloch.forifixeradmin.fragment;

import android.annotation.SuppressLint;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.shahnizarbaloch.forifixeradmin.R;
import com.shahnizarbaloch.forifixeradmin.RecyclerView.DoneOrderRecyclerView;
import com.shahnizarbaloch.forifixeradmin.model.getOrderBy;

import java.util.ArrayList;
import java.util.Objects;


@SuppressLint("ValidFragment")
public class CompleteOrders extends Fragment {

    //ArrayList of Everything Class
    private ArrayList<getOrderBy> arrayList;
    DatabaseReference databaseReference;
    DoneOrderRecyclerView adapter;
    ProgressBar progressBar;
    //View which will be used in some other places
    View view;
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view=inflater.inflate(R.layout.complete_order_fragment,container,false);
        progressBar = view.findViewById(R.id.progressBar);
        progressBar.setVisibility(View.VISIBLE);
        RecyclerView recyclerView = view.findViewById(R.id.order_recycler_view);
        adapter = new DoneOrderRecyclerView(arrayList,getContext());
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(Objects.requireNonNull(getContext()),DividerItemDecoration.VERTICAL);
        dividerItemDecoration.setDrawable(getResources().getDrawable(R.drawable.divider));
        recyclerView.addItemDecoration(dividerItemDecoration);
        recyclerView.setAdapter(adapter);

        return view;
    }


    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private ArrayList<getOrderBy> getUser(){
        final ArrayList<getOrderBy> arrayListUser = new ArrayList<>();
        final DatabaseReference myRef=databaseReference.child("DoneOrder");
        myRef.addValueEventListener(new ValueEventListener() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                arrayList.clear();
                for(DataSnapshot ds : dataSnapshot.getChildren()) {
                    String uid = ds.getKey();
                    Log.d("TAG", uid);
                    assert uid != null;
                    String Name= Objects.requireNonNull(dataSnapshot.child(uid).child("name").getValue()).toString();
                    String Email= Objects.requireNonNull(dataSnapshot.child(uid).child("email").getValue()).toString();
                    String Number= Objects.requireNonNull(dataSnapshot.child(uid).child("number").getValue()).toString();
                    String Location= Objects.requireNonNull(dataSnapshot.child(uid).child("location").getValue()).toString();
                    String Total= Objects.requireNonNull(dataSnapshot.child(uid).child("total").getValue()).toString();
                    Log.d("Name", Name);
                    Log.d("Email", Email);
                    Log.d("Number", Number);
                    Log.d("Location", Location);
                    Log.d("Total", Total);
                    arrayListUser.add(new getOrderBy(uid,Name,Email,Number,Location,Total));
                    adapter.notifyDataSetChanged();
                }
                progressBar.setVisibility(View.GONE);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Failed to read value
                Toast.makeText(getContext(), "Failed To Load Data!", Toast.LENGTH_SHORT).show();
            }
        });
        return arrayListUser;
    }


    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        arrayList = new ArrayList<>();
        databaseReference = FirebaseDatabase.getInstance().getReference("Users");
        arrayList=getUser();

        //Adding Things Here.. Means when we patch data from firebase then we can add them here ;)

    }
}
