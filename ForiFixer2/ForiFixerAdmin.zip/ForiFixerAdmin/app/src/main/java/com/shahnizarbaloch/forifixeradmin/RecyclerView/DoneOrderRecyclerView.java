package com.shahnizarbaloch.forifixeradmin.RecyclerView;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.shahnizarbaloch.forifixeradmin.R;
import com.shahnizarbaloch.forifixeradmin.activity.OrderDetailActivity;
import com.shahnizarbaloch.forifixeradmin.model.getOrderBy;

import java.util.ArrayList;

public class DoneOrderRecyclerView extends android.support.v7.widget.RecyclerView.Adapter<DoneOrderRecyclerView.MyViewHolder>{


    private ArrayList<getOrderBy> arrayList;
    private Context context;


    public DoneOrderRecyclerView(ArrayList<getOrderBy> arrayList, Context context) {
        this.arrayList=arrayList;
        this.context=context;
    }

    @NonNull
    @Override
    public DoneOrderRecyclerView.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflater = LayoutInflater.from(context);
        @SuppressLint("InflateParams") final View view = inflater.inflate(R.layout.order_by_home_screen, null, false);
        final MyViewHolder myViewHolder = new MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull DoneOrderRecyclerView.MyViewHolder myViewHolder, final int i) {
        final getOrderBy obj = arrayList.get(i);
        myViewHolder.tvName.setText(obj.getName());
        myViewHolder.tvNumber.setText(obj.getNumber());
        myViewHolder.tvEmail.setText(obj.getEmail());
        myViewHolder.tvLocation.setText(obj.getLocation());
        myViewHolder.tvTotal.setText(obj.getTotal());
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    class MyViewHolder extends android.support.v7.widget.RecyclerView.ViewHolder{
        RelativeLayout orderBy;
        TextView tvName,tvNumber,tvEmail,tvLocation,tvTotal;
        android.support.v7.widget.RecyclerView rv;
        MyViewHolder(@NonNull View itemView) {
            super(itemView);
            orderBy = itemView.findViewById(R.id.item_rv);
            tvName=itemView.findViewById(R.id.tv_name);
            tvNumber=itemView.findViewById(R.id.tv_contact_number);
            tvEmail=itemView.findViewById(R.id.tv_email_address);
            tvLocation=itemView.findViewById(R.id.tv_location);
            tvTotal=itemView.findViewById(R.id.total);
            rv = itemView.findViewById(R.id.order_recycler_view);
        }
    }
}
