package com.shahnizarbaloch.forifixeradmin.RecyclerView;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.shahnizarbaloch.forifixeradmin.R;
import com.shahnizarbaloch.forifixeradmin.activity.OrderDetailActivity;
import com.shahnizarbaloch.forifixeradmin.model.getOrderBy;
import com.shahnizarbaloch.forifixeradmin.model.itemDetail;

import java.security.AccessControlContext;
import java.util.ArrayList;

public class OrderRecyclerView extends android.support.v7.widget.RecyclerView.Adapter<OrderRecyclerView.MyViewHolder>{

    private ProgressBar progressBar;
    private ArrayList<getOrderBy> arrayList;
    private Context context;
    private DatabaseReference databaseReference;


    public OrderRecyclerView(ArrayList<getOrderBy> arrayList, Context context) {
        this.arrayList=arrayList;
        this.context=context;
    }

    @NonNull
    @Override
    public OrderRecyclerView.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflater = LayoutInflater.from(context);
        @SuppressLint("InflateParams") final View view = inflater.inflate(R.layout.order_by_home_screen, null, false);
        progressBar=view.findViewById(R.id.progressBar);
        /*//AppCompatActivity is for transaction of fragments
        final AppCompatActivity activity = (AppCompatActivity) view.getContext();
*/      databaseReference = FirebaseDatabase.getInstance().getReference().child("Users");
        final MyViewHolder myViewHolder = new MyViewHolder(view);


        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull OrderRecyclerView.MyViewHolder myViewHolder, final int i) {
        final getOrderBy obj = arrayList.get(i);
        myViewHolder.tvName.setText(obj.getName());
        myViewHolder.tvNumber.setText(obj.getNumber());
        myViewHolder.tvEmail.setText(obj.getEmail());
        myViewHolder.tvLocation.setText(obj.getLocation());
        myViewHolder.tvTotal.setText(obj.getTotal());
        final DatabaseReference myRef = databaseReference.child("OrderBy");
        final DatabaseReference myRef2=databaseReference.child("OrderDetails");
        myViewHolder.orderBy.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                final String Key=obj.getId();
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setCancelable(true);
                builder.setTitle("Order");
                builder.setMessage("Delete For Order Deletion, And Done For Order Completion!");
                builder.setPositiveButton("Delete Order",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                progressBar.setVisibility(View.VISIBLE);
                                myRef.child(Key).removeValue();
                                myRef2.child(Key).removeValue();
                                progressBar.setVisibility(View.GONE);
                            }
                        });
                builder.setNegativeButton("Done Order", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        progressBar.setVisibility(View.VISIBLE);
                        DatabaseReference doneOrder = databaseReference.child("DoneOrder");
                        doneOrder.push().setValue(new getOrderBy(Key,obj.getName(),obj.getEmail(),obj.getNumber(),obj.getLocation(),obj.getTotal()));
                        myRef.child(Key).removeValue();
                        myRef2.child(Key).removeValue();
                        arrayList.remove(arrayList.size() - 1);
                        progressBar.setVisibility(View.GONE);

                    }
                });

                AlertDialog dialog = builder.create();
                dialog.show();
                return true;
            }
        });
        myViewHolder.orderBy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Key=obj.getId();
                Intent intent = new Intent(context, OrderDetailActivity.class);
                intent.putExtra("Key",Key);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    class MyViewHolder extends android.support.v7.widget.RecyclerView.ViewHolder{
        RelativeLayout orderBy;
        TextView tvName,tvNumber,tvEmail,tvLocation,tvTotal;
        android.support.v7.widget.RecyclerView rv;
        MyViewHolder(@NonNull View itemView) {
            super(itemView);
            orderBy = itemView.findViewById(R.id.item_rv);
            tvName=itemView.findViewById(R.id.tv_name);
            tvNumber=itemView.findViewById(R.id.tv_contact_number);
            tvEmail=itemView.findViewById(R.id.tv_email_address);
            tvLocation=itemView.findViewById(R.id.tv_location);
            tvTotal=itemView.findViewById(R.id.total);
            rv = itemView.findViewById(R.id.order_recycler_view);
        }
    }
}
